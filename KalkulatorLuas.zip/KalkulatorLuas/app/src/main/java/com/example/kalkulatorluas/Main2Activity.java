package com.example.kalkulatorluas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    private EditText alas, tinggi;
    private TextView tvHasil;
    private Button btnsegitiga;
    private double sHasil = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnsegitiga = findViewById(R.id.btn_segitiga);
        alas = findViewById(R.id.et_alas);
        tinggi = findViewById(R.id.et_tinggi);
        tvHasil = findViewById(R.id.tv_hasil);


        btnsegitiga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Double Alas = Double.parseDouble(alas.getText().toString());
                    Double Tinggi = Double.parseDouble(tinggi.getText().toString());

                    Double segitiga =  Alas * Tinggi/2;
                    tvHasil.setText(String.valueOf(segitiga));

                }catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Field tidak boleh kosong", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
