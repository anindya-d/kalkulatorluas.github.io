package com.example.kalkulatorluas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btn_segitiga;
    private Button btn_jajargenjang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_segitiga = findViewById(R.id.btn_segitiga);
        btn_jajargenjang = findViewById(R.id.btn_jajargenjang);


        btn_segitiga.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent moveIntent = new Intent(MainActivity.this ,
                        Main2Activity.class);
                startActivity(moveIntent);
            }
        });
        btn_jajargenjang.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent moveIntent = new Intent(MainActivity.this ,
                        Main3Activity.class);
                startActivity(moveIntent);
            }
        });
    }

}
